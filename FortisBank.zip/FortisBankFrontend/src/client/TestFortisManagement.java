package client;

//soniya nathani
//nidhi oza
//david vacca
//isabela pamplona

import java.io.IOException;
import java.util.Date;
import java.util.Scanner;

import bus.Customer;
import bus.DataCollection;
import bus.FileManager;
import bus.RaiseException;
import bus.Account;
import bus.AccountType;
import bus.CheckingAccount;
import bus.CreditAccount;
import bus.CurrencyAccount;
import bus.SavingsAccount;
import bus.StatusType;
import bus.Validator;

public class TestFortisManagement {
	static Customer c = null;
	static Scanner in = new Scanner(System.in);

	public static void main(String[] args) {
		int option = 0;
		
		do {
			// Print options
			option = displayMainMenu();
			try {
				Validator.isInRange(option, 0, 7);
				start(option);
			} catch (RaiseException e) {
				System.out.println("\n"+e.getMessage()+"\n");
				
			}
		} while(option != 0);
		in.close();
	}
	
	private static void start(int option) throws RaiseException {
		switch(option) {
			case 1:
				c = createCustomer();
				break;
			case 2:
				if(DataCollection.getListOfCustomers().size() != 0) {
					c = getCustomer();
					createAccount();
				} else
					throw new RaiseException("Create a customer first");
				break;
			case 3:
				if(DataCollection.getListOfCustomers().size() != 0) {
					c = getCustomer();
					deleteAccount();
				} else
					throw new RaiseException("Create a customer first");
				break;
			case 4:
				if(DataCollection.getListOfCustomers().size() != 0) {
					c = getCustomer();
					deleteCustomer();
				} else
					throw new RaiseException("Create a customer first");
				break;
			case 5:
				//create a "create transaction" method
				break;
			case 6:
				save();
				break;
			case 7:
				load();
				break;
		}
		
	}

	private static Customer getCustomer() {
		while(true) {
			System.out.print("Customer Id: ");
			int customerId = in.nextInt();
			Customer found = DataCollection.getListOfCustomers().stream().filter(customer -> customer.getvIdNumber() == customerId).findFirst().orElse(null);
			if (found != null) 
				return found;
		}
	}

	private static void save() {
		try {
			FileManager.writeToSerializedFile(DataCollection.getListOfCustomers());
			System.out.println("\nData saved....\n");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void load() {
		try {
			DataCollection.setListOfCustomers(FileManager.readFromSerializedFile());
			System.out.println("\nData loaded....\n");
		} catch (ClassNotFoundException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static int displayMainMenu() {	
		int selection;
				
		System.out.println("Welcome to Fortis Bank System\n");
		System.out.println("----- Main Menu -----\n");
		System.out.println("1 - Create Customer\n");
		System.out.println("2 - Create Account\n");
		System.out.println("3 - Close Account\n");
		System.out.println("4 - Delete Customer\n");
		System.out.println("5 - Create Transaction\n");
		System.out.println("6 - Save state\n");
		System.out.println("7 - Load state\n");
		System.out.println("0 - Exit\n");
		// Ask an option
		System.out.print("Select an option (1 - 7): ");
		// Read the option
		selection = in.nextInt();
		// Return the option
		return selection;
	}
	
	private static int displayMenuAccounts(String action) {
		int selection;
		
		System.out.println("Welcome to Fortis Bank System\n");
		System.out.println("----- Menu Accounts -----\n");
		System.out.println("1 - " + action + " Saving Account\n");
		System.out.println("2 - " + action + " Credit Account\n");
		System.out.println("3 - " + action + " Currency Account\n");
		System.out.println("0 - Exit\n");
		// Ask an option
		System.out.print("Select an option (1 - 3): ");
		// Read the option
		selection = in.nextInt();
		// Return the option
		return selection;
	}
	
	private static void deleteCustomer() {
		DataCollection.delete(c);
	}
	
	private static void deleteAccount() throws RaiseException {
		int option = displayMenuAccounts("Delete");
		Validator.isInRange(option, 0, 3);
		Account found = null;
		switch(option) {
			case 1:
				// Check if already have an saving account and get it
				found = c.getListAccount().stream().filter(account -> account instanceof SavingsAccount).findFirst().orElse(found);
				if(found == null) {
					System.out.println("No existing saving account");
					return;
				}
				break;
			case 2:
				// Check if already have an credit account and get it
				found = c.getListAccount().stream().filter(account -> account instanceof CreditAccount).findFirst().orElse(found);
				if(found == null) {
					System.out.println("No existing credit account");
					return;
				}
				break;
			case 3:
				//check if already have an currency account and get it
				found = c.getListAccount().stream().filter(account -> account instanceof CurrencyAccount).findFirst().orElse(found);
				if(found == null) {
					System.out.println("No existing currency account");
					return;
				}
				break;
		}
		c.removeAccount(found);
	}
	
	private static void createAccount() throws RaiseException {
		int option = displayMenuAccounts("Create");
		Validator.isInRange(option, 0, 3);
		Account found = null;
		
		switch(option) {
			case 1:
				//check if already have an saving account
				found = c.getListAccount().stream().filter(account -> account instanceof SavingsAccount).findFirst().orElse(found);
				if(found == null) {
					System.out.println("Savings account creation");
					System.out.print("Enter account number: ");
					// Read the data
					int accountNumber = in.nextInt();
					System.out.print("Enter interest rate: ");
					// Read the data
					Double intRate = in.nextDouble();
					System.out.print("Enter annual gain: ");
					// Read the data
					Double annualGain = in.nextDouble();
					System.out.print("Enter extra fee: ");
					// Read the data
					Double extraFee = in.nextDouble();
					c.addAccount(new SavingsAccount(accountNumber, AccountType.savings, new Date(), 0.0, StatusType.opened, intRate, annualGain, extraFee));
				} else {
					System.out.println("The customer already has a saving account");
				}
				break;
			case 2:
				//check if already have an credit account
				found = c.getListAccount().stream().filter(account -> account instanceof CreditAccount).findFirst().orElse(found);
				if(found == null) {
					System.out.println("Credit account creation");
					System.out.print("Enter account number: ");
					// Read the data
					int accountNumber = in.nextInt();
					c.addAccount(new CreditAccount(accountNumber, AccountType.credit, new Date(), 0.0, StatusType.opened));
				} else {
					System.out.println("The customer already has a credit account");
				}
				break;
			case 3:
				//check if already have an currency account
				found = c.getListAccount().stream().filter(account -> account instanceof CurrencyAccount).findFirst().orElse(found);
				if(found == null) {
					System.out.println("Currency account creation");
					System.out.print("Enter account number: ");
					// Read the data
					int accountNumber = in.nextInt();
					c.addAccount(new CurrencyAccount(accountNumber, AccountType.currency, new Date(), 0.0, StatusType.opened));
				} else {
					System.out.println("The customer already has a currency account");
				}
				break;
		}
	}
	
	private static Customer createCustomer() {
		// Read the data
		System.out.print("Enter id number: ");
		int idNumber = in.nextInt();
		System.out.print("Enter name: ");
		String name = in.next();
		System.out.print("Enter pin: ");
		String pin = in.next();
		
		Customer myCustomer = new Customer(idNumber, name, pin);
		// Create checkingAccount
		
		System.out.println("Checking account creation");
		System.out.print("Enter account number: ");
		// Read the data
		int accountNumber = in.nextInt();
		System.out.print("Enter extra fee: ");
		// Read the data
		Double extraFee = in.nextDouble();
		CheckingAccount ca = new CheckingAccount(accountNumber, AccountType.checking, new Date(), 0.0, StatusType.opened, extraFee);
		// Add the checkingAccount to myCostumer
		myCustomer.addAccount(ca);
		
		boolean answer = false;
		// Ask to create savingAccount
		System.out.println("Press Y to create a savings account: ");
		// read answer
		String creationSaving = in.next();
		if(creationSaving.equalsIgnoreCase("y")) {
			answer = true;
		}
		
		if (answer) {
			// Create saving account
			System.out.println("Savings account creation");
			System.out.print("Enter account number: ");
			// Read the data
			accountNumber = in.nextInt();
			System.out.print("Enter interest rate: ");
			// Read the data
			Double intRate = in.nextDouble();
			System.out.print("Enter annual gain: ");
			// Read the data
			Double annualGain = in.nextDouble();
			System.out.print("Enter extra fee: ");
			// Read the data
			extraFee = in.nextDouble();
			SavingsAccount sa = new SavingsAccount(accountNumber, AccountType.checking, new Date(), 0.0, StatusType.opened, intRate, annualGain, extraFee);
			// Add the checkingAccount to myCostumer
			myCustomer.addAccount(sa);
		}	

		DataCollection.add(myCustomer);
		return myCustomer;
	}
}
