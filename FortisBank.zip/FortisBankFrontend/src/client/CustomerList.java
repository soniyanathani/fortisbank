package client;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

import bus.Customer;

import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;
import java.awt.Color;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Pattern;

import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JCheckBox;

public class CustomerList extends JFrame {

	private JPanel contentPane;
	private JTextField txtSearch;
	private JTable customerTable;
	private TableRowSorter<DefaultTableModel> rowSorter;
	
	private String [] columns = new String [] {
            "Customer Number", "Customer name", "Options"
    };
	private ImageIcon iconEdit;
	private JScrollPane scrollPane;

	/**
	 * Create the frame.
	 */
	public CustomerList() {
		setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);
		setBounds(100, 100, 775, 577);
		contentPane = new JPanel();
		contentPane.setForeground(new Color(0, 0, 128));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("MANAGE CUSTOMERS");
		lblNewLabel.setForeground(new Color(0, 0, 128));
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblNewLabel.setBounds(241, 41, 307, 37);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Search : ");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(198, 134, 86, 25);
		contentPane.add(lblNewLabel_1);
		
		txtSearch = new JTextField();
		txtSearch.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtSearch.setBounds(280, 135, 217, 25);
		contentPane.add(txtSearch);
		txtSearch.setColumns(10);
		txtSearch.getDocument().addDocumentListener(new DocumentListener(){

            @Override
            public void insertUpdate(DocumentEvent e) {
            	String text = txtSearch.getText();

                if (text.trim().length() == 0) {
                    rowSorter.setRowFilter(null);
                } else {
                	rowSorter.setRowFilter(RowFilter.regexFilter(Pattern.compile(text, Pattern.CASE_INSENSITIVE).toString()));
                }
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
            	String text = txtSearch.getText();

                if (text.trim().length() == 0) {
                    rowSorter.setRowFilter(null);
                } else {
                    rowSorter.setRowFilter(RowFilter.regexFilter(Pattern.compile(text, Pattern.CASE_INSENSITIVE).toString()));
                }
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

        });
		
		JButton btnBack = new JButton("Back");
		btnBack.setBounds(539, 134, 89, 23);
		btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
		contentPane.add(btnBack);
		
		JButton btnNew = new JButton("New");
		btnNew.setBounds(539, 183, 89, 23);
		btnNew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
		contentPane.add(btnNew);
		
		Image img;
		try {
			img = ImageIO.read(getClass().getResource("/edit.png")).getScaledInstance(20, 20, java.awt.Image.SCALE_SMOOTH);
			iconEdit = new ImageIcon(img);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		};
		customerTable = new JTable();
		customerTable.setModel(new javax.swing.table.DefaultTableModel(null, columns) {
            //  Returning the Class of each column will allow different
            //  renderers to be used based on Class
            public Class getColumnClass(int column) {
                return getValueAt(0, column).getClass();
            }
            public boolean isCellEditable(int row, int column) {
            	if(column == 0 || column == 2) return false;
              return true;//This causes all cells to be not editable
            }
        });
		customerTable.getColumnModel().getColumn(2).setPreferredWidth(50);
		customerTable.addMouseListener(new java.awt.event.MouseAdapter() {
			@Override
			public void mouseClicked(java.awt.event.MouseEvent evt) {
			    int row = customerTable.rowAtPoint(evt.getPoint());
			    int col = customerTable.columnAtPoint(evt.getPoint());
			    if (row >= 0 && col == 2) {
			    	//int input = JOptionPane.showConfirmDialog(null, "Do you want delete the register", "DELETE", JOptionPane.YES_NO_OPTION);
			    	//if (input == 0) {
			    	openCustomerManager((int)customerTable.getValueAt(row, 0));
			    }
			 }
		});
        loadTableData();
        scrollPane = new JScrollPane(customerTable);
        scrollPane.setBounds(87, 232, 589, 213);
		contentPane.add(scrollPane);
		
		rowSorter = new TableRowSorter<DefaultTableModel>((DefaultTableModel) customerTable.getModel());
		
		JLabel lblLogo = new JLabel("");
		img = new ImageIcon(this.getClass().getResource("/logo.png")).getImage();
		lblLogo.setIcon(new ImageIcon(img));
		lblLogo.setBounds(10, 11, 105, 148);
		contentPane.add(lblLogo);
	}
	
	private void loadTableData() {
		ArrayList<Customer> myCustomers = new ArrayList<Customer>();
    	
		try {
			myCustomers = Customer.all();
		} catch (NumberFormatException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Object[][] data = new Object[myCustomers.size()][3];
		for (int i = 0; i < myCustomers.size(); i++) {
			data[i][0] = myCustomers.get(i).getvIdNumber();
			data[i][1] = myCustomers.get(i).getvName();
			data[i][2] = iconEdit;
		}
		((DefaultTableModel) customerTable.getModel()).setDataVector(data, columns);
	}

	private void jButton1ActionPerformed(ActionEvent evt) {
		dispose();
	}
	
	private void jButton2ActionPerformed(ActionEvent evt) {
		openCustomerManager(0);
	}
	
	private void openCustomerManager(int customerId) {
		CustomerManager cm = new CustomerManager(this, true, customerId);
		cm.setVisible(true);
        cm.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
            	loadTableData();
            }
            @Override
            public void windowClosing(WindowEvent e) {
            	loadTableData();
            }
        });
	}
}
