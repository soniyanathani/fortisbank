package client;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.border.EmptyBorder;

import bus.Customer;
import bus.RaiseException;
import bus.Validator;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionEvent;
import java.sql.SQLException;
import java.awt.Font;
import java.awt.Image;
import java.awt.Color;
import javax.swing.JTextField;

public class CustomerManager extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField txtID;
	private JTextField txtName;
	private JPasswordField txtPin;
	private JButton btnDelete;
	
	
	private int customerId = 0;

	/**
	 * Create the dialog.
	 * @param customerId 
	 * @param b 
	 * @param customerList 
	 */
	public CustomerManager(java.awt.Frame parent, boolean modal, int customerId) {
		super(parent, modal);
		this.customerId = customerId;
		initComponents();
	}

	private void initComponents() {
		setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);
		setBounds(100, 100, 775, 560);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblNewLabel = new JLabel("CREATE CUSTOMER");
			lblNewLabel.setForeground(new Color(0, 0, 128));
			lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 30));
			lblNewLabel.setBounds(233, 24, 288, 46);
			contentPanel.add(lblNewLabel);
		}
		{
			JLabel lblLogo = new JLabel("");
			Image img = new ImageIcon(this.getClass().getResource("/logo.png")).getImage();
			lblLogo.setIcon(new ImageIcon(img));
			lblLogo.setBounds(22, 24, 113, 134);
			contentPanel.add(lblLogo);
		}
		{
			JLabel lblIdNumber = new JLabel("ID Number : ");
			lblIdNumber.setFont(new Font("Tahoma", Font.PLAIN, 14));
			lblIdNumber.setBounds(233, 164, 84, 33);
			contentPanel.add(lblIdNumber);
		}
		{
			JLabel lblName = new JLabel("Name : ");
			lblName.setFont(new Font("Tahoma", Font.PLAIN, 14));
			lblName.setBounds(233, 219, 84, 33);
			contentPanel.add(lblName);
		}
		{
			JLabel lblPin = new JLabel("Pin :");
			lblPin.setFont(new Font("Tahoma", Font.PLAIN, 14));
			lblPin.setBounds(233, 276, 84, 33);
			contentPanel.add(lblPin);
		}
		{
			txtID = new JTextField();
			txtID.setFont(new Font("Tahoma", Font.PLAIN, 16));
			txtID.setBounds(327, 170, 258, 25);
			contentPanel.add(txtID);
			txtID.setColumns(10);
		}
		{
			txtName = new JTextField();
			txtName.setFont(new Font("Tahoma", Font.PLAIN, 16));
			txtName.setColumns(10);
			txtName.setBounds(327, 227, 258, 25);
			contentPanel.add(txtName);
		}
		{
			txtPin = new javax.swing.JPasswordField();
			txtPin.setFont(new Font("Tahoma", Font.PLAIN, 16));
			txtPin.setColumns(10);
			txtPin.setBounds(327, 284, 258, 25);
			contentPanel.add(txtPin);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton btnSave = new JButton("Save");
				btnSave.addActionListener(new java.awt.event.ActionListener() {
		            public void actionPerformed(java.awt.event.ActionEvent evt) {
		                jButton1ActionPerformed(evt);
		            }
		        });
				buttonPane.add(btnSave);
				getRootPane().setDefaultButton(btnSave);
			}
			{
				btnDelete = new JButton("Delete");
				btnDelete.addActionListener(new java.awt.event.ActionListener() {
		            public void actionPerformed(java.awt.event.ActionEvent evt) {
		                jButton2ActionPerformed(evt);
		            }
		        });
				btnDelete.setEnabled(false);
				buttonPane.add(btnDelete);
			}
			{
				JButton btnCancel = new JButton("Cancel");
				btnCancel.addActionListener(new java.awt.event.ActionListener() {
		            public void actionPerformed(java.awt.event.ActionEvent evt) {
		                jButton3ActionPerformed(evt);
		            }
		        });
				buttonPane.add(btnCancel);
			}
		}
		
		if(this.customerId != 0) {
        	setInitialData();
        }
	}

	private void setInitialData() {
		txtID.setText(Integer.toString(customerId));
		txtID.setEnabled(false);
		
		btnDelete.setEnabled(true);
		
		try {
    		Customer cus = Customer.search(customerId);
    		txtName.setText(cus.getvName());
    		txtPin.setText(cus.getvPin());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void jButton1ActionPerformed(ActionEvent evt) {
		if(customerId == 0) {
			createCustomer();
		} else {
			updateCustomer();
		}
	}
	
	private void createCustomer() {
		if(txtName.getText().isBlank() || String.valueOf(txtPin.getPassword()).isBlank() || txtID.getText().isBlank()) {
			JOptionPane.showMessageDialog(null, "The values are empty", "Apocalyptic message", JOptionPane.WARNING_MESSAGE);
			return;
		}
		try {
			Validator.isInteger(txtID.getText());
		} catch (RaiseException e) {
			JOptionPane.showMessageDialog(null, "The customer ID is invalid", "Apocalyptic message", JOptionPane.WARNING_MESSAGE);
			return;
		}
		int idNumber = Integer.parseInt(txtID.getText());
		String name = txtName.getText();
		String pin = String.valueOf(txtPin.getPassword());
		Customer myCustomer = new Customer(idNumber, name, pin);
		// Validate if the customer exists
		try {
			if(Validator.existsCustomer(idNumber)) {
				JOptionPane.showMessageDialog(null, "The customer already exists", "Apocalyptic message", JOptionPane.WARNING_MESSAGE);
				return;
			}
		} catch (SQLException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		try {
			Customer.add(myCustomer);
			showSuccess("created");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	
	private void updateCustomer() {
		if(txtName.getText().isBlank() || String.valueOf(txtPin.getPassword()).isBlank()) {
			JOptionPane.showMessageDialog(null, "The values are empty", "Apocalyptic message", JOptionPane.WARNING_MESSAGE);
			return;
		}
		String name = txtName.getText();
		String pin = String.valueOf(txtPin.getPassword());
		Customer myCustomer = new Customer(customerId, name, pin);
		// Validate if the customer exists
		try {
			if(!Validator.existsCustomer(customerId)) {
				JOptionPane.showMessageDialog(null, "The customer doesn't exist","Apocalyptic message", JOptionPane.WARNING_MESSAGE);
				return;
			}
		} catch (SQLException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		try {
			Customer.update(myCustomer);
			showSuccess("updated");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	protected void jButton2ActionPerformed(ActionEvent evt) {
		// Validate if the customer exists
		try {
			if(!Validator.existsCustomer(customerId)) {
				JOptionPane.showMessageDialog(null, "The customer doesn't exists","Apocalyptic message", JOptionPane.WARNING_MESSAGE);
				return;
			}
		} catch (SQLException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		try {
			Customer.delete(customerId);
			showSuccess("deleted");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	protected void jButton3ActionPerformed(ActionEvent evt) {
		dispose();
	}
	
	private void showSuccess(String message) {
		JOptionPane.showMessageDialog(null, "Customer " + message, "Success", JOptionPane.INFORMATION_MESSAGE);
		dispose();
	}

}
