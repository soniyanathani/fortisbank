package data;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import bus.AccountType;
import bus.CheckingAccount;
import bus.Customer;
import bus.StatusType;

public class CustomerDB {
	
	static private Connection myConnection = null;
	static private String mySQLCommand = null;
	static private String mySQLQuery = null;
	static private Statement myStatement = null;
	static private ResultSet myResultSet = null;
	
	static private int rowAffected;
		
	/*
	 * return 1 if added successfully otherwise 0
	 */
	public static int insert(Customer aNewCustomer) throws SQLException {
		
		myConnection = DBConnection.getConnection();
		rowAffected = 0;
		
 
       mySQLCommand = "insert into Customer(vIdNumber, vName, vPin)  values( " 
                                       + aNewCustomer.getvIdNumber() 
                                       + "  ,  \'" 
                                       + aNewCustomer.getvName()  
                                       + "\'  ,  \'"
                                       + aNewCustomer.getvPin() 
                                       + "\' )" ;
		
		
		//in the command Line (SQL *PLUS):

		
		try {
			
			myStatement = myConnection.createStatement();
			
			rowAffected = myStatement.executeUpdate(mySQLCommand);
			
			myConnection.commit();
			
			if(rowAffected > 0) {
				return 1;
			}else {
				return 0;
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
			return 0;
		}
	}
	
	public static ArrayList<Customer> select() throws SQLException, NumberFormatException{
		
		Customer customer = null;
		myConnection = DBConnection.getConnection();
		
		mySQLQuery= "SELECT * FROM Customer";
		
		myStatement = myConnection.createStatement();
		
		myResultSet = myStatement.executeQuery(mySQLQuery);
		
		
		ArrayList<Customer> myList = new ArrayList<Customer>();
		
				while(myResultSet.next()) {
					
					try {
						customer = new Customer(myResultSet.getInt(1),myResultSet.getString(2), myResultSet.getString(3));
					} catch (NumberFormatException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					myList.add(customer);
				}
		
		return myList;
	}
	
	
	public static int delete(int id ) throws SQLException {
		
		myConnection = DBConnection.getConnection();
		rowAffected = 0;
		
		//if id is of the String type, your command will be as follows:
		      //mySQLCommand = "Delete FROM Department WHERE Dept_Number = \'"  + id + "\'";
		
		mySQLCommand = "Delete FROM Customer WHERE vIdNumber = "  + id  ;
		
		try {
			
			myStatement = myConnection.createStatement();
			
			int rowAffected = myStatement.executeUpdate(mySQLCommand);		
			
			myConnection.commit();
			
			if(rowAffected > 0) {
				return 1;
			}else {
				return 0;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return 0;
		}
	}


	public static boolean exists(int customerId) throws SQLException {
		myConnection = DBConnection.getConnection();
		mySQLCommand = "SELECT COUNT(*) FROM Customer WHERE vIdNumber = "  + customerId  ;
		
		try {
			
			myStatement = myConnection.createStatement();
			
			myResultSet = myStatement.executeQuery(mySQLCommand);		
			
			myResultSet.next();
			
			if(myResultSet.getInt(1) > 0) {
				return true;
			}else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		
	}
	
	public static int update(Customer customer) throws SQLException {
		
		myConnection = DBConnection.getConnection();
		rowAffected  = 0 ;
		
       mySQLCommand = "Update Customer SET vName = \'"+customer.getvName()+"\', vPin = \'" + customer.getvPin()  
                                                    + "\' WHERE  vIdNumber = "  + customer.getvIdNumber() ;
		
		try {
			
			myStatement = myConnection.createStatement();
			
			rowAffected = myStatement.executeUpdate(mySQLCommand);
			
			                       myConnection.commit();
			
			if(rowAffected > 0) {
				return 1;
			}else {
				return 0;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
			return 0;
		}
	}
	
	public static int search(String name, String pin) throws SQLException, SQLException{
		int customerId = 0;
		myConnection = DBConnection.getConnection();
		
		mySQLQuery = "SELECT vIdNumber FROM Customer WHERE vName = \'" + name + "\' AND vPin = \'" + pin + "\'";
		
		myStatement = myConnection.createStatement();
		
		myResultSet = myStatement.executeQuery(mySQLQuery);
		
		
		if(myResultSet.next()) {			
			
			customerId = myResultSet.getInt(1);
		}
		
		return customerId;
	}
	
	public static Customer search2(int customerId) throws SQLException, SQLException{
		Customer customer = null;
		myConnection = DBConnection.getConnection();
		
		mySQLQuery = "SELECT * FROM Customer WHERE vIdNumber = " + customerId;
		
		myStatement = myConnection.createStatement();
		
		myResultSet = myStatement.executeQuery(mySQLQuery);
		
		
		if(myResultSet.next()) {			
			
			customer = new Customer(myResultSet.getInt(1),myResultSet.getString(2), myResultSet.getString(3));
		}
		
		return customer;
	}

}
