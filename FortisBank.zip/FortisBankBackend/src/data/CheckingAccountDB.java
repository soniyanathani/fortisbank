package data;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.sql.Date;

import bus.AccountType;
import bus.CheckingAccount;
import bus.Customer;
import bus.SavingsAccount;
import bus.StatusType;

public class CheckingAccountDB {
	
	static private Connection myConnection = null;
	static private String mySQLCommand = null;
	static private String mySQLQuery = null;
	static private Statement myStatement = null;
	static private ResultSet myResultSet = null;
	
	static private CheckingAccount aCheckingAccount = null;
	
	
	static private int rowAffected;
		
	/*
	 * return 1 if added successfully otherwise 0
	 */
	public static int insert(CheckingAccount aNewCheckingAccount, int vIdNumber) throws SQLException {
		
		myConnection = DBConnection.getConnection();
		rowAffected = 0;
		Date newDate = new Date(aNewCheckingAccount.getvOpenDate().getTime());
		
 
       mySQLCommand = "insert into CheckingAccount (vAccountNumber, accountType, vOpenDate, vBalance, vStatus, vExtraFee, vIdNumber)  values( " 
                                       + aNewCheckingAccount.getvAccountNumber() 
                                       + "  ,  \'" 
                                       + aNewCheckingAccount.getvAccountType().toString()  
                                       + "\',  TO_DATE(\'"
                                       + newDate
                                       + "\', \'yyyy-mm-dd\'),  "
                                       + aNewCheckingAccount.getvBalance() 
                                       + ",  \'"
                                       + aNewCheckingAccount.getvStatus().toString()
                                       + "\',  "
                                       + aNewCheckingAccount.getvExtraFee()
                                       + ",  "
                                       + vIdNumber
                                       + " )" ;
		
		
		//in the command Line (SQL *PLUS):
       
		try {
			
			myStatement = myConnection.createStatement();
			
			rowAffected = myStatement.executeUpdate(mySQLCommand);
			
			                 myConnection.commit();
			
			if(rowAffected > 0) {
				return 1;
			}else {
				return 0;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return 0;
		}
	}
	
	
	public static ArrayList<CheckingAccount> select() throws SQLException, NumberFormatException{
		
		myConnection = DBConnection.getConnection();
		
		mySQLQuery= "SELECT * FROM CheckingAccount";
		
		myStatement = myConnection.createStatement();
		
		myResultSet = myStatement.executeQuery(mySQLQuery);
		
		
		ArrayList<CheckingAccount> myList = new ArrayList<CheckingAccount>();
		
				while(myResultSet.next()) {
					
					try {
						aCheckingAccount = new CheckingAccount(myResultSet.getInt(1),
												     AccountType.valueOf(myResultSet.getString(2)),
												     new SimpleDateFormat("yyyy-MM-dd").parse(myResultSet.getString(3)),
								                     Double.parseDouble(myResultSet.getString(4)),
								                     StatusType.valueOf(myResultSet.getString(5)),
								                     Double.parseDouble(myResultSet.getString(6)));
					} catch (NumberFormatException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					myList.add(aCheckingAccount);
				}
		
		return myList;
	}
	
	public static int delete(int id ) throws SQLException {
		
		myConnection = DBConnection.getConnection();
		rowAffected = 0;
		
		//if id is of the String type, your command will be as follows:
		      //mySQLCommand = "Delete FROM Department WHERE Dept_Number = \'"  + id + "\'";
		
		mySQLCommand = "Delete FROM SavingsAccount WHERE vIdNumber = "  + id  ;
		
		try {
			
			myStatement = myConnection.createStatement();
			
			int rowAffected = myStatement.executeUpdate(mySQLCommand);		
			
			myConnection.commit();
			
			if(rowAffected > 0) {
				return 1;
			}else {
				return 0;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return 0;
		}
	}


	public static boolean exists(int customerId)  throws SQLException {
		myConnection = DBConnection.getConnection();
		mySQLCommand = "SELECT COUNT(*) FROM CheckingAccount WHERE vIdNumber = "  + customerId  ;
		
		try {
			
			myStatement = myConnection.createStatement();
			
			myResultSet = myStatement.executeQuery(mySQLCommand);		
			
			myResultSet.next();
			
			if(myResultSet.getInt(1) > 0) {
				return true;
			}
			return false;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	

	public static int update(CheckingAccount ca) throws SQLException {
		
		myConnection = DBConnection.getConnection();
		rowAffected  = 0 ;
		
       mySQLCommand = "Update CheckingAccount SET vExtraFee =  " + ca.getvExtraFee() 
                                                    + " WHERE  vAccountNumber = " +  ca.getvAccountNumber();
		
		try {
			
			myStatement = myConnection.createStatement();
			
			rowAffected = myStatement.executeUpdate(mySQLCommand);
			
			                       myConnection.commit();
			
			if(rowAffected > 0) {
				return 1;
			}else {
				return 0;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
			return 0;
		}
	}
	
	public static CheckingAccount search(int customerId) throws SQLException, SQLException{
		myConnection = DBConnection.getConnection();
		
		mySQLQuery = "SELECT vAccountNumber, vBalance FROM CheckingAccount WHERE vIdNumber = "  + customerId  ;
		
		myStatement = myConnection.createStatement();
		
		myResultSet = myStatement.executeQuery(mySQLQuery);
		
		if(myResultSet.next()) {			
			aCheckingAccount = new CheckingAccount();
			aCheckingAccount.setvAccountNumber(myResultSet.getInt(1));
			aCheckingAccount.setvBalance(myResultSet.getDouble(2));
		}
		
		return aCheckingAccount;
	}
	
	public static CheckingAccount search2(int accountNumber) throws SQLException, SQLException{
		myConnection = DBConnection.getConnection();
		
		mySQLQuery = "SELECT vIdNumber, accountType, vOpenDate, vBalance, vStatus, vExtraFee FROM CheckingAccount WHERE vAccountNumber = "  + accountNumber  ;
		
		myStatement = myConnection.createStatement();
		
		myResultSet = myStatement.executeQuery(mySQLQuery);
		
		if(myResultSet.next()) {			
			try {
				aCheckingAccount = new CheckingAccount(myResultSet.getInt(1),
					     AccountType.valueOf(myResultSet.getString(2)),
					     new SimpleDateFormat("yyyy-MM-dd").parse(myResultSet.getString(3)),
				        Double.parseDouble(myResultSet.getString(4)),
				        StatusType.valueOf(myResultSet.getString(5)),
				        Double.parseDouble(myResultSet.getString(6)));
			} catch (NumberFormatException | SQLException | ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return aCheckingAccount;
	}
}
