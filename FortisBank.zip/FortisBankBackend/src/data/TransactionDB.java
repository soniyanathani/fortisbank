package data;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import bus.AccountType;
import bus.Transaction;
import bus.TransactionType;

public class TransactionDB {
	static private Connection myConnection = null;
	static private String mySQLCommand = null;
	static private String mySQLQuery = null;
	static private Statement myStatement = null;
	static private ResultSet myResultSet = null;
	
	static private Transaction aTransaction = null;
	
	static private int rowAffected;
	
	/*
	 * return 1 if added successfully otherwise 0
	 */
	public static int insert(Transaction aTransaction, int vAccountNumber, AccountType at) throws SQLException {
		myConnection = DBConnection.getConnection();
		rowAffected = 0;
		Date newDate = new Date(aTransaction.getvTransactionDate().getTime());
		
 
       mySQLCommand = "insert into Transaction (vTransactionNumber, accountType, vDescription, vTransactionDate, vTransactionType, vTransactionAmount, vAccountNumber)  values( " 
                                       + aTransaction.getvTransactionNumber() 
                                       + ",  \'" 
                                       + at.toString()  
                                       + "\',  \'" 
                                       + aTransaction.getvDescription()
                                       + "\',  TO_DATE(\'"
                                       + newDate
                                       + "\', \'yyyy-mm-dd\'), \'"
                                       + aTransaction.getvTransactionType().toString()
                                       + "\',  "
                                       + aTransaction.getvTransactionAmount()
                                       + ",  "
                                       + vAccountNumber
                                       + " )" ;
		
		
		//in the command Line (SQL *PLUS):
       
		try {
			
			myStatement = myConnection.createStatement();
			
			rowAffected = myStatement.executeUpdate(mySQLCommand);
			
			double realAmount = aTransaction.getvTransactionType() == TransactionType.deposit ? aTransaction.getvTransactionAmount() : -1*aTransaction.getvTransactionAmount();
			mySQLCommand = updateBalance(at, vAccountNumber, realAmount);
			myStatement.executeUpdate(mySQLCommand);
			
			myConnection.commit();
			
			if(rowAffected > 0) {
				return 1;
			}else {
				return 0;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return 0;
		}
		
	}
	
	private static String updateBalance(AccountType at, int accountNumber, double realAmount) {
		String myCommand = "";
		switch(at) {
			case checking:
				myCommand = "Update CheckingAccount SET vBalance =  vBalance + " + realAmount
                + " WHERE  vAccountNumber = " +  accountNumber;
				break;
			case savings:
				myCommand = "Update SavingsAccount SET vBalance =  vBalance + " + realAmount
                + " WHERE  vAccountNumber = " +  accountNumber;
				break;
			case currency:
				myCommand = "Update CurrencyAccount SET vBalance =  vBalance + " + realAmount
                + " WHERE  vAccountNumber = " +  accountNumber;
				break;
			case credit:
			default:
				myCommand = "Update CreditAccount SET vBalance =  vBalance + " + realAmount
                + " WHERE  vAccountNumber = " +  accountNumber;
				break;
		}
		return myCommand;
	}

	public static ArrayList<Transaction> select(int vAccountNumber, AccountType at) throws SQLException, NumberFormatException{
		
		myConnection = DBConnection.getConnection();
		
		mySQLQuery= "SELECT * FROM Transaction WHERE accountType = \'" + at.toString() + "\' AND vAccountNumber = " + vAccountNumber;
		
		myStatement = myConnection.createStatement();
		
		myResultSet = myStatement.executeQuery(mySQLQuery);
		
		
		ArrayList<Transaction> myList = new ArrayList<Transaction>();
		
				while(myResultSet.next()) {
					
					try {
						aTransaction = new Transaction(myResultSet.getInt(1),
													myResultSet.getString(3), 
													new SimpleDateFormat("yyyy-MM-dd").parse(myResultSet.getString(4)), 
													TransactionType.valueOf(myResultSet.getString(5)), 
													Double.parseDouble(myResultSet.getString(6)));
					} catch (NumberFormatException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					myList.add(aTransaction);
				}
		
		return myList;
	}
	
	public static int delete(int id ) throws SQLException {
		
		myConnection = DBConnection.getConnection();
		rowAffected = 0;
		
		//if id is of the String type, your command will be as follows:
		      //mySQLCommand = "Delete FROM Department WHERE Dept_Number = \'"  + id + "\'";
		
		mySQLCommand = "Delete FROM Transaction WHERE vTransactionNumber = "  + id  ;
		
		try {
			
			myStatement = myConnection.createStatement();
			
			int rowAffected = myStatement.executeUpdate(mySQLCommand);		
			
			myConnection.commit();
			
			if(rowAffected > 0) {
				return 1;
			}else {
				return 0;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return 0;
		}
	}

	public static int update(Transaction tr) throws SQLException {
		
		myConnection = DBConnection.getConnection();
		rowAffected  = 0 ;
		
       mySQLCommand = "Update Transaction SET vDescription =  \'" + tr.getvDescription()  
                                                    + "\' WHERE  vTransactionNumber = " +  tr.getvTransactionNumber();
		
		try {
			
			myStatement = myConnection.createStatement();
			
			rowAffected = myStatement.executeUpdate(mySQLCommand);
			
			                       myConnection.commit();
			
			if(rowAffected > 0) {
				return 1;
			}else {
				return 0;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
			return 0;
		}
	}
}
