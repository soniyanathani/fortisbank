package bus;

import java.sql.SQLException;
import java.util.Collection;
import java.util.Date;

import data.CheckingAccountDB;

public class CheckingAccount extends Account {

	private double vExtraFee;
	
	//Empty constructor of the child class Checking Account;
	public CheckingAccount() {}
	
	//constructor with one parameter:
	//Constructor of the child class Checking Account with 6 attributes;
	public CheckingAccount(int accountNumber, AccountType at, Date creationDate, double balance, StatusType status, Double extraFee) {
		super(accountNumber, at, creationDate, balance, status);
		this.vExtraFee = extraFee;
	}
	
	//Method to recuperate the value of the checking Account's number, which returns a variable of type double;
	public double getvExtraFee() {
		return vExtraFee;
	}
	
	//Method to set the value of the extra fee, which does not return anything (void);
	public void setvExtraFee(double vExtraFee) {
		this.vExtraFee = vExtraFee;
	}
	
	//Method to add a checking account to a customer, which returns a variable of type integer;
	public static int add(CheckingAccount ca, int idCustomer) throws SQLException {
		return CheckingAccountDB.insert(ca, idCustomer);
	}

	public static CheckingAccount search(int accountNumber) throws SQLException {
		return CheckingAccountDB.search2(accountNumber);
	}

	public static int update(CheckingAccount myAccount) throws SQLException {
		return CheckingAccountDB.update(myAccount);
	}

	public static Collection<CheckingAccount> all() throws NumberFormatException, SQLException {
		return CheckingAccountDB.select();
	}

	public static Account searchByCustomer(int customerId) throws SQLException {
		return CheckingAccountDB.search(customerId);
	}

}