package bus;

import java.sql.SQLException;

import data.CheckingAccountDB;
import data.SavingsAccountDB;
import data.CurrencyAccountDB;
import data.CreditAccountDB;
import data.CustomerDB;

public class Validator {
	
	//Method that validates if a value is in a certain range, which returns a variable of type boolean;
	public static boolean isInRange(int value, int min, int max) throws RaiseException {
		if( value < min  || value > max) {
			throw new RaiseException("invalid input; value must be between "+min+" and "+max);
		}
		return true;
	}
	
	//Method that validates if a value is a digit, which returns a variable of type boolean;
	public static boolean isDigit(String value) throws RaiseException {
		if(value.length() > 1 || !Character.isDigit(value.charAt(0))) {
			throw new RaiseException("invalid input; value isn't a digit");
		}	
		return true;	
	}
	
	
	//Method that validates if a value is a character, which returns a variable of type boolean;
	public static boolean isChar(String value) throws RaiseException {
		if( value.length() > 1) {
			throw new RaiseException("invalid input; value isn't a char");
		}	
		return true;	
	}
	
	//Method that validates if a value is of type integer, which returns a variable of type boolean;
	public static boolean isInteger(String value) throws RaiseException {
		try {
			Integer.parseInt(value);
			return true;
		}catch(NumberFormatException e) {
			throw new RaiseException("invalid input; value isn't integer");
		}	
	}
	
	//Method that validates if a value is of type double, which returns a variable of type boolean;
	public static boolean isDouble(String value) throws RaiseException {
		try {
			Double.parseDouble(value);
			return true;
		}catch(NumberFormatException e) {
			throw new RaiseException("invalid input; value isn't double");
		}	
	}
	
	//Method that validates if a customer exists, which returns a variable of type boolean;
	public static boolean existsCustomer(int id) throws SQLException {
		return CustomerDB.exists(id);
	}
	
	//Method that validates if an account exists, which returns a variable of type boolean;
	public static boolean existsAccount(AccountType at, int idCustomer) throws SQLException {
		switch(at) {
			case checking:
				return CheckingAccountDB.exists(idCustomer);
			case savings:
				return SavingsAccountDB.exists(idCustomer);
			case currency:
				return CurrencyAccountDB.exists(idCustomer);
			case credit:
				return CreditAccountDB.exists(idCustomer);
			default:
				return false;
		}
	}
}
