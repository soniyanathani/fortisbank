package bus;


public class InsufficientAmountException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private final static String message = "RAISE Exception...Fortis business rules" ;
	
	//Empty constructor of the exception class InsufficientAmountException;
	public InsufficientAmountException() {
		super(message);
	}
	
	//Empty constructor of the exception class InsufficientAmountException, containing 1 attribute;
	public InsufficientAmountException(String newMessage) {
		super(newMessage);
	}

}
