package bus;

public enum TransactionType {
	deposit, //Constant of the enum class Transaction Type to set it as a deposit;
	withdraw //Constant of the enum class Transaction Type to set it as a withdraw;
} 