package bus;

import java.util.Comparator;

//Empty constructor of the class NumberPredicate;
public class NumberPredicate implements Comparator<Account> {

	@Override
	//Method to compare accounts, which returns a variable of type integer;
	public int compare(Account o1, Account o2) {
		// TODO Auto-generated method stub
		return o1.getvAccountNumber() > o2.getvAccountNumber() ? 1 : -1;
	}

}
