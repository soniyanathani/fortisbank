package bus;

public enum StatusType {
	opened, //Constant of the enum class Status Type to set it as an opened account;
	closed //Constant of the enum class Status Type to set it as a closed account;
}
