package bus;

import java.util.HashMap;

public class SingletonBank {
	private static  SingletonBank singleInstance = null;
	//From Java API:
	        // The implementation provides constant-time performance for the basic operations (get and put)
	private HashMap<String, Account> listOfAccounts = null  ;
	private HashMap<String, CheckingAccount> listOfChecking = null  ;
	private HashMap<String, SavingsAccount> listOfSavings = null  ;
	
	// private HashMap<String, City> listOfCities  ;
	
	private SingletonBank()
	 {
		listOfAccounts = new HashMap<String, Account> () ;
		listOfChecking = new HashMap<String, CheckingAccount> () ;
		listOfSavings = new HashMap<String, SavingsAccount> () ;
	 }
	
	//Method to recuperate the value of an instance of SingletonBank, which returns an a type SingletonBank;
	public static SingletonBank getSingletonBank() {
		 if(singleInstance == null)
		 {
			 singleInstance = new SingletonBank();
			 
		 }		 
		return singleInstance;
	}	
	
	//Method to recuperate the value of the account's HashMap, which returns a variable of type HashMap;
	public HashMap<String, Account> getAccountHashMap() {
		return singleInstance.listOfAccounts;
	}
	
	//Method to recuperate the value of the checkings account's HashMap, which returns a variable of type HashMap;
	public HashMap<String, CheckingAccount> getCheckingAccountHashMap() {
		return singleInstance.listOfChecking;
	}
	
	//Method to recuperate the value of the savings account's HashMap, which returns a variable of type HashMap;
	public HashMap<String, SavingsAccount> getSavingAccountHashMap() {
		return singleInstance.listOfSavings;
	}
	
	//Method to add an account, which does not return anything (void);
    public  void add(Account acc)	{		
		singleInstance.listOfAccounts.put(Integer.toString(acc.getvAccountNumber()), acc);	
	}
    
    //Method to remove an account, which does not return anything (void);
    public  void remove(Account acc)	{
		
		singleInstance.listOfAccounts.remove(acc.getvAccountNumber());	
	}
    
    //Method to search, which returns an Account;
    public Account search(String  key){
		Account element = null;
        if (singleInstance.listOfAccounts.containsKey(key)){
        	
          element = singleInstance.listOfAccounts.get(key);
        }       
        
        return element;
    }

}
