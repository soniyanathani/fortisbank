package bus;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import data.TransactionDB;

public class Transaction {

	private int vTransactionNumber; 
	private String vDescription; //maybe the description could be an enum too?
	private Date vTransactionDate;
	private TransactionType vTransactionType;
	private double vTransactionAmount;

	//empty constructor with the initialized variables
	//Empty constructor of the class Transaction;
	public Transaction() {
		vTransactionNumber = 0000; // we will probably create and autogerated methos for this
		vDescription = "add a description";
		vTransactionDate = new Date(); //how to call today's date in Java?
		vTransactionType = TransactionType.deposit;
		vTransactionAmount = 0;
	}
	//constructor with 5 parameters
	//Constructor of the class Transaction, containing 5 attributes;
	public Transaction (int transactionNumber, String description, Date transactionDate, TransactionType transactionType, 
			double transactionAmount) {
		this.vTransactionNumber = transactionNumber;
		this.vDescription = description;
		this.vTransactionDate = transactionDate;
		this.vTransactionType = transactionType;
		this.vTransactionAmount = transactionAmount;
	}
	
	//Method to recuperate the value of the transaction's number, which returns a variable of type integer;
	public int getvTransactionNumber() {
		return vTransactionNumber;
	}
	
	//Method to set the value of the transaction's number, which does not return anything (void);
	public void setvTransactionNumber(int vTransactionNumber) {
		this.vTransactionNumber = vTransactionNumber; 
	}
	
	//Method to recuperate the value of the transaction's description, which returns a variable of type string;
	public String getvDescription() {
		return vDescription;
	}
	
	//Method to set the value of the transaction's description, which does not return anything (void);
	public void setvDescription(String vDescription) {
		this.vDescription = vDescription; 
	}
	
	//Method to recuperate the value of the transaction's date, which returns a variable of type date;
	public Date getvTransactionDate() {
		return vTransactionDate;
	}
	
	//Method to set the value of the transaction's date, which does not return anything (void);
	public void setvTransactionDate(Date vTransactionDate) {
		this.vTransactionDate = vTransactionDate;
	}
	
	//Method to recuperate the value of the transaction's type, which returns a variable of TransactionType;
	public TransactionType getvTransactionType() {
		return vTransactionType;
	}
	
	//Method to set the value of the transaction's type, which does not return anything (void);
	public void setvTransactionType(TransactionType vTransactionType) {
		this.vTransactionType = vTransactionType;
	}
	
	//Method to recuperate the value of the transaction's amount, which returns a variable of type double;
	public double getvTransactionAmount() {
		return vTransactionAmount;
	}
	
	//Method to set the value of the transaction's amount, which does not return anything (void);
	public void setvTransactionAmount(double vTransactionAmount) {
		this.vTransactionAmount = vTransactionAmount;
	}
	
	public static int add(Transaction aTransaction, int accountNumber, AccountType accountType) throws SQLException {
		return TransactionDB.insert(aTransaction, accountNumber, accountType);
	}
	
	public static ArrayList<Transaction> all(int accountNumber, AccountType accountType) throws NumberFormatException, SQLException {
		return TransactionDB.select(accountNumber, accountType);
	}
	
	

}