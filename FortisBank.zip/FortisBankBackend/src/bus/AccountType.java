package bus;

public enum AccountType {
	checking, //Constant of the enum class Account Type to set it as a checking account;
	savings, //Constant of the enum class Account Type to set it as a savings account;
	credit, //Constant of the enum class Account Type to set it as a credit account;
	currency //Constant of the enum class Account Type to set it as a currency account;
}