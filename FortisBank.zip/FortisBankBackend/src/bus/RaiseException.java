package bus;

public class RaiseException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private final static String message = "RAISE Exception...Fortis business rules" ;
	
	//Empty constructor of the exception class RaiseException;
	public RaiseException() {
		super(message);
	}
	
	//Empty constructor of the exception class RaiseException, containing 1 attribute;
	public RaiseException(String newMessage) {
		super(newMessage);
	}

}
