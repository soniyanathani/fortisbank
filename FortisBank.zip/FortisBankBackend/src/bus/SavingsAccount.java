package bus;

import java.sql.SQLException;
import java.util.Collection;
import java.util.Date;

import data.CreditAccountDB;
import data.SavingsAccountDB;

public class SavingsAccount extends Account {

	private double vInterestRate;
	private double vAnnualGain;
	private double vExtraFee;
	
	//Empty constructor of the child class SavingsAccount;
	public SavingsAccount() {}
	
	//constructor with the 3 parameters:
	//Constructor of the class SavingsAccount, containing 8 attributes;
	public SavingsAccount(int accountNumber, AccountType at, Date creationDate, double balance, StatusType status, double interestRate, double annualGain, double extraFee) {
		super(accountNumber, at, creationDate, balance, status);
		this.vInterestRate = interestRate;
		this.vAnnualGain = annualGain;
		this.vExtraFee = extraFee;
	}
	
	//Method to recuperate the value of the savings Account's interest rate, which returns a variable of type double;
	public double getvInterestRate() {
		return vInterestRate;
	}
	
	//Method to set the value of the savings Account's interest rate, which does not return anything (void);
	public void setvInterestRate(double vInterestRate) {
		this.vInterestRate = vInterestRate;
	}
	
	//Method to recuperate the value of the savings Account's annual gain, which returns a variable of type double;
	public double getvAnnualGain() {
		return vAnnualGain;
	}
	
	//Method to set the value of the savings Account's annual gain, which does not return anything (void);
	public void setvAnnualGain(double vAnnualGain) {
		this.vAnnualGain = vAnnualGain;
	}
	
	//Method to recuperate the value of the savings Account's extra fee, which returns a variable of type double;
	public double getvExtraFee() {
		return vExtraFee;
	}
	
	//Method to set the value of the savings Account's extra fee, which does not return anything (void);
	public void setvExtraFee(double vExtraFee) {
		this.vExtraFee = vExtraFee;
	}
	
	//Method to add a savings account to a customer, which returns a variable of type integer;
	public static int add(SavingsAccount sa, int idCustomer) throws SQLException {
		return SavingsAccountDB.insert(sa, idCustomer);
	}

	//Method to delete a savings account from a customer, which returns a variable of type integer;
	public static int delete(int id) throws SQLException {
		return SavingsAccountDB.delete(id);
	}

	public static SavingsAccount search(int accountNumber) throws SQLException {
		return SavingsAccountDB.search2(accountNumber);
	}

	public static int update(SavingsAccount myAccount) throws SQLException {
		return SavingsAccountDB.update(myAccount);
	}

	public static Collection<SavingsAccount> all() throws NumberFormatException, SQLException {
		return SavingsAccountDB.select();
	}

	public static Account searchByCustomer(int customerId) throws SQLException {
		return SavingsAccountDB.search(customerId);
	}
}
