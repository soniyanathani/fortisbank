package bus;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

//Empty constructor of the class FileManager;
public class FileManager {
	static String filepath = "src//data//fortis-file.bank";
	
	//Method to write to a serialized file, which does not return anything (void);
	public static void writeToSerializedFile(ArrayList<Customer> listOfCustomers) throws IOException {
		File myFile = new File(filepath);
		myFile.createNewFile();
		FileOutputStream fos = new FileOutputStream(myFile);
		ObjectOutputStream oos = new ObjectOutputStream(fos);	
		oos.writeObject(listOfCustomers);
		fos.close();		
	}	
	@SuppressWarnings("unchecked")
	//Method to read from the serialized file, which returns a variable of type ArrayList;
	public static ArrayList <Customer>  readFromSerializedFile() throws IOException, ClassNotFoundException {
		ArrayList<Customer> listOfCustomersFromFile = new ArrayList<Customer>();
		File myFile = new File(filepath);
		myFile.createNewFile();
		FileInputStream fis = new FileInputStream(myFile);
		ObjectInputStream ois = new ObjectInputStream(fis);		  
		listOfCustomersFromFile = (ArrayList<Customer>) ois.readObject();		  
		fis.close();			  
		return listOfCustomersFromFile;	
	} 	
}
