package bus;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;

public abstract class Account implements Serializable {

	/**
	 *Empty constructor of the abstract class Account;
	 *author: David vacca
	 *Isabela pamplona
	 *Nidhi oza
	 *Soniya nathani
	 *
	 *date: 15-12-2021
	 */
	private static final long serialVersionUID = 1L;
	private int vAccountNumber;
	private AccountType vAccountType;
	private Date vOpenDate;
	private double vBalance;
	private StatusType vStatus;
	private ArrayList<Transaction> aListTransactions = new ArrayList<Transaction>();
	
	/**
	 * empty-default constructor with the variables initialized
	 */
	public Account() {
		vAccountNumber = 0000; //after we will change this to an automated generator or something
		vAccountType = AccountType.checking;
		vOpenDate = new Date();
		vBalance = 0;
		vStatus = StatusType.opened;	
	}
	
	/**
	 * constructor with 5 parameters
	 * @param accountNumber
	 * @param accountType
	 * @param openDate
	 * @param balance
	 * @param status
	 */
	public Account(int accountNumber, AccountType accountType, Date openDate, double balance, StatusType status) {
			
		this.vAccountNumber = accountNumber;
		this.vAccountType = accountType;
		this.vOpenDate = openDate;
		this.vBalance = balance;
		this.vStatus = status;
			
	}

	// then we have to add methods for 
	//Open, 
	//Close (delete), 
	//ShowBalance(inside transactions?)
	//DisplayBalance (or will it also be in transactions?)
	//Transfer (or will it also be in transactions?)
	//Deposit
	//Withdraw

	/**
	 * Method to recuperate the value of the Account's number, which returns a variable of type integer;
	 * @return
	 */
	public int getvAccountNumber() {
		return vAccountNumber;
	}
	
	/**
	 * Method to set the value of the Account's number, which does not return anything (void);
	 * @param vAccountNumber
	 */
	public void setvAccountNumber(int vAccountNumber) {
		this.vAccountNumber = vAccountNumber;
	}
	
	/**
	 * Method to recuperate the value of the Account's type, which returns a variable of type AccountType;
	 * @return
	 */
	public AccountType getvAccountType() {
		return vAccountType;
	}
	
	/**
	 * Method to set the value of the Account's type, which does not return anything (void);
	 * @param vAccountType
	 */
	public void setvAccountType(AccountType vAccountType) {
		this.vAccountType = vAccountType;
	}
	
	/**
	 * Method to recuperate the value of the Account's opening date, which returns a variable of type Date;
	 * @return
	 */
	public Date getvOpenDate() {
		return vOpenDate;
	}
	
	/**
	 * Method to set the value of the Account's opening Date, which does not return anything (void);
	 * @param vOpenDates
	 */
	public void setvOpenDate(Date vOpenDates) {
		this.vOpenDate = vOpenDates;
	}
	
	/**
	 * Method to recuperate the value of the Account's balance, which returns a variable of type double;
	 * @return
	 */
	public double getvBalance() {
		return vBalance;
	}
	
	/**
	 * Method to set the value of the Account's balance, which does not return anything (void);
	 * @param vBalance
	 */
	public void setvBalance(double vBalance) {
		this.vBalance = vBalance;
	}
	
	/**
	 * Method to recuperate the value of the Account's status type, which returns a variable of type StatusType;
	 * @return
	 */
	public StatusType getvStatus() {
		return vStatus;
	}
	
	/**
	 * Method to set the value of the Account's status, which does not return anything (void);
	 * @param vStatus
	 */
	public void setvStatus(StatusType vStatus) {
		this.vStatus = vStatus;
	}

}