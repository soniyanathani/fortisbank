package bus;

import java.sql.SQLException;
import java.util.Collection;
import java.util.Date;

import data.CreditAccountDB;
import data.CurrencyAccountDB;

public class CreditAccount extends Account {
	
	//Empty constructor of the child class CreditAccount;
	public CreditAccount() {}

	//just and empty constructor for now
	//Constructor of the class CreditAccount, containing 5 attributes;
	public CreditAccount(int accountNumber, AccountType at, Date creationDate, double balance, StatusType status) {
		super(accountNumber, at, creationDate, balance, status);
	}
	
	//Method to add a checking account to a customer, which returns a variable of type integer;
	public static int add(CreditAccount ca, int idCustomer) throws SQLException {
		return CreditAccountDB.insert(ca, idCustomer);
	}

	//Method to delete a checking account to a customer, which returns a variable of type integer;
	public static int delete(int id) throws SQLException {
		return CreditAccountDB.delete(id);
	}

	public static CreditAccount search(int accountNumber) throws SQLException {
		return CreditAccountDB.search2(accountNumber);
	}

	public static Collection<CreditAccount> all() throws NumberFormatException, SQLException {
		return CreditAccountDB.select();
	}

	public static Account searchByCustomer(int customerId) throws SQLException {
		return CreditAccountDB.search(customerId);
	}
}