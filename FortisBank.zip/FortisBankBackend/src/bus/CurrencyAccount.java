package bus;

import java.sql.SQLException;
import java.util.Collection;
import java.util.Date;

import data.CurrencyAccountDB;
import data.CustomerDB;


public class CurrencyAccount extends Account {
	//just and empty constructor for now
	
	//Empty constructor of the child class CurrencyAccount;
	public CurrencyAccount() {}
	
	//Constructor of the child class CurrencyAccount containing 5 attributes;
	public CurrencyAccount(int accountNumber, AccountType at, Date creationDate, double balance, StatusType status) {
		super(accountNumber, at, creationDate, balance, status);
	}
	
	//Method to add a currency account to a customer, which returns a variable of type integer;
	public static int add(CurrencyAccount ca, int idCustomer) throws SQLException {
		return CurrencyAccountDB.insert(ca, idCustomer);
	}
	
	//Method to delete a currency account to a customer, which returns a variable of type integer;
	public static int delete(int id) throws SQLException {
		return CurrencyAccountDB.delete(id);
	}

	public static CurrencyAccount search(int accountNumber) throws SQLException {
		return CurrencyAccountDB.search2(accountNumber);
	}

	public static Collection<CurrencyAccount> all() throws NumberFormatException, SQLException {
		return CurrencyAccountDB.select();
	}

	public static Account searchByCustomer(int customerId) throws SQLException {
		return CurrencyAccountDB.search(customerId);
	}
}