package bus;

import java.util.ArrayList;

//Empty constructor of the class DataCollection;
public class DataCollection {
	private static ArrayList<Customer> listOfCustomers = new ArrayList<Customer>();
	
	
	//Method to recuperate the value of the customer's list (ListOfCustomers), which returns a variable of type ArrayList;
	public static ArrayList<Customer> getListOfCustomers() {
		return listOfCustomers;
	}

	//Method to set a value to the customer's list (ListOfCustomers), which does not return anything (void);
	public static void setListOfCustomers(ArrayList<Customer> listOfCities) {
		DataCollection.listOfCustomers = listOfCities;
	}

	//Method to add a customer to the list of customers, which does not return anything (void);
	public static void add(Customer customer) {
		listOfCustomers.add(customer);		
	}
	
	//Method to delete a customer to the list of customers, which does not return anything (void);
	public static void delete(Customer customer) {
		listOfCustomers.remove(customer);
	}
}
