package bus;

import java.io.Serializable;
import java.sql.SQLException;
import java.util.ArrayList;

import data.CurrencyAccountDB;
import data.CustomerDB;

public class Customer implements Serializable {

	/**
	 *Empty constructor of the abstract class Account;
	 *author: David vacca
	 *Isabela pamplona
	 *Nidhi oza
	 *Soniya nathani
	 *
	 *date: 15-12-2021
	 */
	private static final long serialVersionUID = 1L;
	private int vIdNumber;
	private String vName;
	private String vPin; //could it be a good idea to use protected for a password?
	private ArrayList<Account> aListAccounts = new ArrayList<Account>();
	
	//empty constructor with initialized variables:
	//Empty constructor of the class Customer;
	public Customer () {
		vIdNumber = 0000; // me might change it later for an automated generator
		vName = "insert a name";
		vPin = "create a password";
	}
	
	//constructor with the parameters:
	//Constructor of the class Customer, containing 3 attributes;
	public Customer (int idNumber, String name, String pin) {
		this.vIdNumber = idNumber;
		this.vName = name;
		this.vPin = pin;
	}
	
	//Method to recuperate the value of the customer's id number, which returns a variable of type integer;
	public int getvIdNumber() {
		return vIdNumber;
	}
	
	//Method to set the value of the customer's id number, which does not return anything (void);
	public void setvIdNumber(int vIdNumber) {
		this.vIdNumber = vIdNumber;
	}
	
	//Method to recuperate the value of the customer's name, which returns a variable of type string;
	public String getvName() {
		return vName;
	}
	
	//Method to set the value of the customer's name, which does not return anything (void);
	public void setvName(String vName) {
		this.vName = vName;
	}

	//Method to recuperate the value of the customer's password, which returns a variable of type string;
	public String getvPin() {
		return vPin;
	}
	
	//Method to set the value of the customer's password, which does not return anything (void);
	public void setvPin(String vPin) {
		this.vPin = vPin;
	}
	
	//Method to recuperate the value of all the accounts of a customer (List Account), which returns a variable of type ArrayList;
	public ArrayList<Account> getListAccount() {
		return aListAccounts;
	}

	//Method to add an account to a customer, which does not return anything (void);
	public void addAccount(Account a) {
		aListAccounts.add(a);
	}
	
	//Method to remove an account from a customer, which does not return anything (void);
	public void removeAccount(Account a) {
		aListAccounts.remove(a);
	}
	
	//Method to add a customer, which returns a variable of type integer;
	public static int add(Customer cu) throws SQLException {
		return CustomerDB.insert(cu);
	}
	
	
	//Method to delete a customer, which returns a variable of type integer;
	public static int delete(int id) throws SQLException {
		return CustomerDB.delete(id);
	}

	public static int update(Customer myCustomer) throws SQLException {
		return CustomerDB.update(myCustomer);
	}

	public static Customer search(int customerId) throws SQLException {
		return CustomerDB.search2(customerId);
	}

	public static ArrayList<Customer> all() throws NumberFormatException, SQLException {
		return CustomerDB.select();
	}

	public static int auth(String name, String pin) throws SQLException {
		return CustomerDB.search(name, pin);
	}

}